<div class="rts-footer-area-two">
        <div class="container-2">
            <div class="row">
                <div class="coll-lg-12">
                    <div class="footer-two-main-wrapper">
                        <div class="single-footer-wized">
                            <!-- <h3 class="footer-title">Need Help? / Contact Us</h3> -->
                            <div class="contact-information">
                                <!-- single contact information -->
                                <div class="single-contact-information-area">
                                    <div class="icon-area">
                                        <img src="{{asset('frontend/new_assets/images/icons/image 10.png')}}" alt="icons">
                                    </div>
                                    
                                </div>
                                <div class="single-contact-information-area">
                                    <div class="icon-area">
                                        <img src="{{asset('frontend/new_assets/images/icons/image 11.png')}}" alt="icons">
                                    </div>
                                    
                                </div>
                                <!-- single contact information emd -->
                                <!-- single contact information -->
                                <div class="single-contact-information-area">
                                    <div class="icon-area">
                                        <img src="{{asset('frontend/new_assets/images/icons/image 12.png')}}" alt="icons">
                                    </div>
                                    
                                </div>
                                <!-- single contact information emd -->
                                <!-- single contact information -->
                                <div class="single-contact-information-area">
                                    <div class="icon-area">
                                        <img src="{{asset('frontend/new_assets/images/icons/image 12.png')}}" alt="icons">
                                    </div>
                                    
                                </div>
                                <div class="single-contact-information-area">
                                    <div class="icon-area">
                                        <img src="{{asset('frontend/new_assets/images/icons/image 12.png')}}" alt="icons">
                                    </div>
                                    
                                </div>
                                <!-- single contact information emd -->
                            </div>
                        </div>
                        <div class="single-footer-wized" style="border-right: 1px solid #000; padding-right: 40px;">
                            <h3 class="footer-title">Customer Center Usage Guide</h3>
                            <div class="contact-information">
                                <!-- single contact information -->
                                <div class="single-contact-information-area">
                                    <!-- <div class="icon-area">
                                        <img src="assets/images/icons/11.svg" alt="icons">
                                    </div> -->
                                    <div class="information-area">
                                        <p class="disc">
                                            Main Phone Number 1577-2288<br>
                                            Dobong TEL: 02-956-6700<br>
                                            Gangnam TEL: 02-538-3000<br>
                                            Gasan TEL: 02-920-9000<br>
                                            FAX: 02-956-0330 FAX:02-515-4554 FAX: 02-852-4554
                                        </p>
                                    </div>
                                </div>
                                <!-- single contact information emd -->
                                <!-- single contact information -->
                                <div class="single-contact-information-area">
                                    <!-- <div class="icon-area">
                                        <img src="assets/images/icons/12.svg" alt="icons">
                                    </div> -->
                                    <div class="information-area">
                                        <p class="disc">
                                            Operating Hours 09:00~18:00 Lunch Time 12:00~13:00<br>
                                            Closed on Weekends and Public Holidays
                                        </p>
                                    </div>
                                </div>
                                <!-- single contact information emd -->
                                <!-- single contact information -->
                                <div class="single-contact-information-area">
                                    <!-- <div class="icon-area">
                                        <img src="assets/images/icons/13.svg" alt="icons">
                                    </div> -->
                                    <div class="information-area">
                                        <p class="disc">
                                            kor@koreagift.com
                                        </p>
                                    </div>
                                </div>
                                <!-- single contact information emd -->
                            </div>
                        </div>
                        <div class="single-footer-wized" style="border-right: 1px solid #000; padding-right: 40px;">
                            <h3 class="footer-title">Customer Center Usage Guide</h3>
                            <div class="contact-information">
                                <!-- single contact information -->
                                <div class="single-contact-information-area">
                                    <!-- <div class="icon-area">
                                        <img src="assets/images/icons/11.svg" alt="icons">
                                    </div> -->
                                    <div class="information-area">
                                        <p class="disc">
                                            Main Phone Number 1577-2288<br>
                                            Dobong TEL: 02-956-6700<br>
                                            Gangnam TEL: 02-538-3000<br>
                                            Gasan TEL: 02-920-9000<br>
                                            FAX: 02-956-0330 FAX:02-515-4554 FAX: 02-852-4554
                                        </p>
                                    </div>
                                </div>
                                <!-- single contact information emd -->
                                <!-- single contact information -->
                                <div class="single-contact-information-area">
                                    <!-- <div class="icon-area">
                                        <img src="assets/images/icons/12.svg" alt="icons">
                                    </div> -->
                                    <div class="information-area">
                                        <p class="disc">
                                            Operating Hours 09:00~18:00 Lunch Time 12:00~13:00<br>
                                            Closed on Weekends and Public Holidays
                                        </p>
                                    </div>
                                </div>
                                <!-- single contact information emd -->
                                <!-- single contact information -->
                                <div class="single-contact-information-area">
                                    <!-- <div class="icon-area">
                                        <img src="assets/images/icons/13.svg" alt="icons">
                                    </div> -->
                                    <div class="information-area">
                                        <p class="disc">
                                            kor@koreagift.com
                                        </p>
                                    </div>
                                </div>
                                <!-- single contact information emd -->
                            </div>
                        </div>
                        <div class="single-footer-wized" style=" padding-right: 40px;">
                            <h3 class="footer-title">Customer Center Usage Guide</h3>
                            <div class="contact-information">
                                <!-- single contact information -->
                                <div class="single-contact-information-area">
                                    <!-- <div class="icon-area">
                                        <img src="assets/images/icons/11.svg" alt="icons">
                                    </div> -->
                                    <div class="information-area">
                                        <p class="disc">
                                            Main Phone Number 1577-2288<br>
                                            Dobong TEL: 02-956-6700<br>
                                            Gangnam TEL: 02-538-3000<br>
                                            Gasan TEL: 02-920-9000<br>
                                            FAX: 02-956-0330 FAX:02-515-4554 FAX: 02-852-4554
                                        </p>
                                    </div>
                                </div>
                                <!-- single contact information emd -->
                                <!-- single contact information -->
                                <div class="single-contact-information-area">
                                    <!-- <div class="icon-area">
                                        <img src="assets/images/icons/12.svg" alt="icons">
                                    </div> -->
                                    <div class="information-area">
                                        <p class="disc">
                                            Operating Hours 09:00~18:00 Lunch Time 12:00~13:00<br>
                                            Closed on Weekends and Public Holidays
                                        </p>
                                    </div>
                                </div>
                                <!-- single contact information emd -->
                                <!-- single contact information -->
                                <div class="single-contact-information-area">
                                    <!-- <div class="icon-area">
                                        <img src="assets/images/icons/13.svg" alt="icons">
                                    </div> -->
                                    <div class="information-area">
                                        <p class="disc">
                                            kor@koreagift.com
                                        </p>
                                    </div>
                                </div>
                                <!-- single contact information emd -->
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- rts footer area end -->
    <div class="rts-footer-area-three" style="border-top: 5px solid #1a5172">
        <div class="container-2">
            <div class="row">
                <div class="coll-lg-12">
                    <div class="footer-three-main-wrapper" style="border-bottom: 2px solid #1a5172">
                        
                        <div class="single-footer-wized" >
                            <h3 class="footer-title">Recruitment Information</h3>
                            
                        </div>
                        <div class="single-footer-wized" >
                            <h3 class="footer-title">Terms of Use</h3>
                            
                        </div>
                        <div class="single-footer-wized" >
                            <h3 class="footer-title">Privacy Policy</h3>
                            
                        </div>
                         <div class="single-footer-wized" >
                            <h3 class="footer-title">Customer Center</h3>
                            
                        </div>
                         <div class="single-footer-wized" >
                            <h3 class="footer-title">Directions</h3>
                            
                        </div>
                         <div class="single-footer-wized" >
                            <h3 class="footer-title">Partner Center</h3>
                            
                        </div>

                    </div>
                </div>
                
            </div>
            <div class="row">
                <div class="coll-lg-12">
                    <div class="footer-three-main-wrapper">
                        
                        <div class="single-footer-wized" >
                            <!-- <h3 class="footer-title">Contact Us</h3> -->
                            <p style="padding-top: 30px; color: #1a5172;">
                                Contact Us<br>
                                경기도 군포시 당정로 90 (당정동) 신라테크노빌 가동 703-2호<br>

                                사업자등록번호: 561-86-01003<br>

                                통신판매업번호: 2018-경기군포-0094호<br>

                                ㈜옥샘코리아 대표이사 원준희 Tel: 010-9432-6867<br>

                                Email:  kfs91@hanmail.net<br>

                                FAX:
                            </p>
                        </div>
                        

                    </div>
                </div>
                
            </div>
        </div>
    </div> 
    <!-- rts copyright area start -->
    <div class="rts-copyright-area-two">
        <div class="container-2">
            <div class="row">
                <div class="col-lg-12">
                    <div class="copyright-arae-two-wrapper">
                        <p class="disc">
                            Copyright 2024 <a href="#">©Ekomart</a>. All rights reserved.
                        </p>
                        <!-- <div class="payment-processw-area">
                            <span>Payment Accepts:</span>
                            <img src="assets/images/payment/04.png" alt="payment">
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script defer src="{{ asset('frontend/new_assets/js/plugins.js') }}"></script>

    <!-- custom js -->
    <script defer src="{{ asset('frontend/new_assets/js/main.js') }}"></script>
    <!-- header style two End -->
     
    
</body>
</html>

<!-- <script>
    var cartItems = pullObjectFromStorage('cartItems')
    $("#top-cart-count").html(cartItems.length)
</script>
@yield('script') -->


<!-- {{-- <iframe name='logiframe' src='lib/sys_checkeb3e.html?referer=&amp;zreferer_ori=' width=0 height=0 frameborder=0
    scrolling=0></iframe> --}} -->
