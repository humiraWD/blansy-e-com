<script language="javascript" src="{{ asset('frontend/js/defaultc66d.js?ver=12') }}"></script>
<script type="text/javascript" src="{{ asset('frontend/js/lightbox.js') }}"></script>
<script type="text/javascript" src="{{ asset('frontend/js/jquery-1.11.1.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('frontend/js/jquery.autocomplete-min.js') }}"></script>
<script type="text/javascript" src="{{ asset('frontend/js/ns-window.js') }}"></script>
<script type="text/javascript" async src="{{ asset('frontend/js/wp_astg_4.0.js') }}"></script>
<script src="{{ asset('frontend/js/clipboard.min.js') }}"></script>
<script src="{{ asset('frontend/js/slick.js') }}" charset="utf-8"></script>
<script src="{{ asset('frontend/js/swiper-bundle.min.js') }}"></script>
<script src="{{ asset('frontend/js/owl.carousel.min.js') }}"></script>
<script type="text/javascript" async src="{{ asset('frontend/js/wp_astg_4.0.js') }}"></script>
<script type="text/javascript" src="{{ asset('frontend/js/wcslog.js') }}"></script>
<script type="text/javascript" charset="UTF-8" src="{{ asset('frontend/js/kp.js') }}"></script>
<script src="{{ asset('frontend/js/rolling8119.js?v=2024012601') }}"></script>
<script src="{{ asset('frontend/js/jquery.scrollbox.min.js') }}"></script>
<script src="{{ asset('frontend/js/jquery.lazyload4b17.js?v=1.9.1') }}"></script>
@yield('script')

<body>
